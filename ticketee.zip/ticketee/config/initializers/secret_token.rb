# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ticketee::Application.config.secret_token = '6ef227ba1a4b25fe3f1eca0f411c04c099bf56cea3c9ddb05d187468b71c597f7dac18a6a66ce57f220cd806a635ca5d42ba5ada1c28fdd42fd355a7a1e83b29'
