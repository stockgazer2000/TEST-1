require 'spec_helper'

describe ProjectsController do

end
