class Project < ActiveRecord::Base
end
